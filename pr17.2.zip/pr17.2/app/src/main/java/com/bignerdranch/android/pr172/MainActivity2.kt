package com.bignerdranch.android.pr172

import android.annotation.SuppressLint
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity2 : AppCompatActivity() {
    lateinit var button: Button
    lateinit var text0: TextView
    lateinit var text1: TextView
    lateinit var edit0: EditText
    lateinit var edit1: EditText
    lateinit var edit2: EditText

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        button=findViewById(R.id.BUTton)
        text0=findViewById(R.id.textView1)
        text1=findViewById(R.id.textView2)
        edit0=findViewById(R.id.editText)
        edit1=findViewById(R.id.editText1)
        edit2=findViewById(R.id.editText2)


        button.setOnClickListener { view: View ->
            try{
                var num0=edit0.text!!.toString()!!.toDouble()
                var num1=edit1.text!!.toString()!!.toDouble()
                var num3=edit2.text!!.toString()!!.toDouble()




                var answer:Double

                answer=num0*2*Math.PI

                text1.setText("Периметр: "+answer)
            }
            catch(e:NumberFormatException) {
                Toast.makeText(this,"неправильно",Toast.LENGTH_SHORT).show()
            }



        }
    }
}